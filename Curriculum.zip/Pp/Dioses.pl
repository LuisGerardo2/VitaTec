es_dios(zeus).
es_esposa_de_zeus(hera).
es_hiji_de_zeus_y_hera(ares).
es_hiji_de_zeus_y_hera(atenea).
%pelicula(nombre,duracion,clasificacion,duracion lista de actores)
%actor(nombre,  numeroDePeliculas, edad)

pelicula(cars,117,infantil,[actor(owen_wilson,10,50),actor(bonnie_hunt,19,60),actor(paul_newman,20,90)]).
pelicula(up,96,aventura,[actor(jordan_nagai,5,27),actor(elie_docter,12,80),actor(bob_peterson,10,40)]).
pelicula(marley_y_yo,115,comedia,[actor(john_grogan,15,56),actor(jennifer_aniston,22,55),actor(erik_dane,22,51)]).
pelicula(una_esposa_de_mentira,117,comedia,[actor(adam_sandler,11,60),actor(jennifer_aniston,22,55)]).
pelicula(cars2,127,infantil,[actor(owen_wilson,10,50),actor(bonnie_hunt,19,60)]).

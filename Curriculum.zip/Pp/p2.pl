es_mas_fuerte_que(krilin,yamcha).
es_mas_fuerte_que(vegeta,krilin).
es_mas_fuerte_que(goku,vegeta).

es_mas_fuerte_que(gohan,vegeta,goku).
